# goit-pycore-hw-03.
Homework 03-04 
